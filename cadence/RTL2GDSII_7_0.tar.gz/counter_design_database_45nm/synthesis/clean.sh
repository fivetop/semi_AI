rm -rf genus.log*
rm -rf genus.cmd*
rm -rf outputs reports test_scripts fv
